-- Create database
CREATE DATABASE scripta;

-- Connect to database
\c scripta;

-- Create tables
CREATE TABLE "Authors" (
    "Id" SERIAL PRIMARY KEY,
    "Name" VARCHAR(200) NOT NULL,
    "Biography" VARCHAR(1000)
);

CREATE TABLE "Genres" (
    "Id" SERIAL PRIMARY KEY,
    "Name" VARCHAR(100) NOT NULL,
    "Description" VARCHAR(500)
);

CREATE TABLE "Books" (
    "Id" SERIAL PRIMARY KEY,
    "Title" VARCHAR(500) NOT NULL,
    "Description" VARCHAR(2000),
    "AuthorId" INTEGER NOT NULL REFERENCES "Authors"("Id"),
    "GenreId" INTEGER NOT NULL REFERENCES "Genres"("Id"),
    "Language" VARCHAR(10) DEFAULT 'ru',
    "Year" INTEGER NOT NULL,
    "Pages" INTEGER NOT NULL,
    "Rating" DECIMAL(3,2) NOT NULL,
    "CoverUrl" VARCHAR(500),
    "FileUrl" VARCHAR(500),
    "Formats" VARCHAR(100) DEFAULT 'PDF',
    "Badge" VARCHAR(50),
    "ViewCount" INTEGER DEFAULT 0,
    "DownloadCount" INTEGER DEFAULT 0,
    "CreatedAt" TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes
CREATE INDEX "IX_Books_Title" ON "Books"("Title");
CREATE INDEX "IX_Books_Rating" ON "Books"("Rating");
CREATE INDEX "IX_Books_CreatedAt" ON "Books"("CreatedAt");
CREATE INDEX "IX_Books_AuthorId" ON "Books"("AuthorId");
CREATE INDEX "IX_Books_GenreId" ON "Books"("GenreId");

-- Insert genres
INSERT INTO "Genres" ("Name", "Description") VALUES
('Роман', 'Художественная проза'),
('Детектив', 'Детективные истории'),
('Фантастика', 'Научная фантастика'),
('Фэнтези', 'Фэнтези произведения'),
('Классика', 'Классическая литература'),
('Поэзия', 'Стихи и поэмы'),
('Бизнес', 'Деловая литература'),
('Психология', 'Психологические книги'),
('История', 'Исторические произведения'),
('Биография', 'Биографии известных людей');

-- Insert authors
INSERT INTO "Authors" ("Name", "Biography") VALUES
('Федор Достоевский', 'Русский писатель, мыслитель'),
('Лев Толстой', 'Русский писатель и мыслитель'),
('Антон Чехов', 'Русский писатель и драматург'),
('Александр Пушкин', 'Русский поэт и писатель'),
('Михаил Булгаков', 'Русский писатель и драматург'),
('Айн Рэнд', 'Американская писательница'),
('Джордж Оруэлл', 'Английский писатель и публицист'),
('Рэй Брэдбери', 'Американский писатель-фантаст'),
('Артур Конан Дойл', 'Британский писатель'),
('Агата Кристи', 'Английская писательница'),
('Дж.Р.Р. Толкин', 'Английский писатель и филолог'),
('Джоан Роулинг', 'Британская писательница'),
('Стивен Кинг', 'Американский писатель'),
('Харуки Мураками', 'Японский писатель'),
('Габриэль Гарсиа Маркес', 'Колумбийский писатель');

-- Insert books
INSERT INTO "Books" ("Title", "Description", "AuthorId", "GenreId", "Language", "Year", "Pages", "Rating", "CoverUrl", "FileUrl", "Formats", "Badge", "ViewCount", "DownloadCount") VALUES
('Преступление и наказание', 'Психологический и философский роман о студенте Раскольникове', 1, 5, 'ru', 1866, 671, 4.8, 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=400', '/files/crime-and-punishment.pdf', 'PDF,EPUB,FB2', 'Лучший', 15420, 8234),
('Война и мир', 'Роман-эпопея о жизни русского общества в эпоху войн против Наполеона', 2, 5, 'ru', 1869, 1225, 4.9, 'https://images.unsplash.com/photo-1512820790803-83ca734da794?w=400', '/files/war-and-peace.pdf', 'PDF,EPUB', 'Лучший', 18935, 9821),
('Мастер и Маргарита', 'Мистический роман о дьяволе, посетившем Москву 1930-х годов', 5, 1, 'ru', 1967, 480, 4.7, 'https://images.unsplash.com/photo-1509021436665-8f07dbf5bf1d?w=400', '/files/master-and-margarita.pdf', 'PDF,EPUB,FB2', 'Рекомендуем', 12563, 7124),
('1984', 'Антиутопия о тоталитарном обществе будущего', 7, 3, 'ru', 1949, 328, 4.6, 'https://images.unsplash.com/photo-1495446815901-a7297e633e8d?w=400', '/files/1984.pdf', 'PDF,EPUB', 'Рекомендуем', 14782, 8956),
('Шерлок Холмс. Полное собрание', 'Все рассказы и повести о знаменитом детективе', 9, 2, 'ru', 1927, 1056, 4.8, 'https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=400', '/files/sherlock-holmes.pdf', 'PDF,EPUB,FB2', 'Лучший', 16234, 9432),
('Убийство в Восточном экспрессе', 'Классический детектив Агаты Кристи', 10, 2, 'ru', 1934, 256, 4.5, 'https://images.unsplash.com/photo-1543002588-bfa74002ed7e?w=400', '/files/murder-orient-express.pdf', 'PDF,EPUB', 'Новый', 8945, 5234),
('Властелин колец', 'Эпическая трилогия о Средиземье', 11, 4, 'ru', 1954, 1178, 4.9, 'https://images.unsplash.com/photo-1589998059171-988d887df646?w=400', '/files/lotr.pdf', 'PDF,EPUB,FB2', 'Лучший', 22456, 13245),
('Гарри Поттер и философский камень', 'Первая книга о юном волшебнике', 12, 4, 'ru', 1997, 332, 4.7, 'https://images.unsplash.com/photo-1621351183012-e2f9972dd9bf?w=400', '/files/harry-potter-1.pdf', 'PDF,EPUB', 'Рекомендуем', 19234, 11567),
('451 градус по Фаренгейту', 'Антиутопия о будущем, где книги запрещены', 8, 3, 'ru', 1953, 256, 4.6, 'https://images.unsplash.com/photo-1524995997946-a1c2e315a42f?w=400', '/files/fahrenheit-451.pdf', 'PDF,EPUB,FB2', 'Рекомендуем', 10456, 6789),
('Анна Каренина', 'Роман о трагической любви', 2, 5, 'ru', 1877, 864, 4.7, 'https://images.unsplash.com/photo-1553729459-efe14ef6055d?w=400', '/files/anna-karenina.pdf', 'PDF,EPUB', 'Лучший', 13567, 7890),
('Евгений Онегин', 'Роман в стихах Александра Пушкина', 4, 6, 'ru', 1833, 224, 4.5, 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400', '/files/eugene-onegin.pdf', 'PDF,EPUB,FB2', 'Новый', 9234, 5678),
('Вишневый сад', 'Пьеса Антона Чехова', 3, 5, 'ru', 1904, 96, 4.4, 'https://images.unsplash.com/photo-1516979187457-637abb4f9353?w=400', '/files/cherry-orchard.pdf', 'PDF,EPUB', 'Новый', 7456, 4123),
('Норвежский лес', 'Роман о любви и взрослении', 14, 1, 'ru', 1987, 296, 4.3, 'https://images.unsplash.com/photo-1497633762265-9d179a990aa6?w=400', '/files/norwegian-wood.pdf', 'PDF,EPUB', 'Новый', 8123, 4567),
('Сто лет одиночества', 'Магический реализм от Маркеса', 15, 1, 'ru', 1967, 448, 4.6, 'https://images.unsplash.com/photo-1519682337058-a94d519337bc?w=400', '/files/one-hundred-years.pdf', 'PDF,EPUB,FB2', 'Рекомендуем', 11234, 6789),
('Атлант расправил плечи', 'Философский роман о капитализме', 6, 1, 'ru', 1957, 1168, 4.5, 'https://images.unsplash.com/photo-1476275466078-4007374efbbe?w=400', '/files/atlas-shrugged.pdf', 'PDF,EPUB', 'Рекомендуем', 9876, 5432);
