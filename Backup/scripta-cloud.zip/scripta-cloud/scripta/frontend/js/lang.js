// Language translations
const translations = {
    az: {
        catalog: 'Kataloq',
        new: 'Yeni',
        favorites: 'Sevimlilər',
        about: 'Haqqımızda',
        search: 'Kitab axtar...',
        heroTitle: 'Sənin şəxsi kitabxanan cibimdə',
        heroSubtitle: 'Bir saytda 500 000-dən çox kitab',
        startReading: 'Pulsuz oxumağa başla',
        recommended: 'Tövsiyə edirik',
        best: 'Ən yaxşılar',
        viewAll: 'Hamısını aç',
        genres: 'Janrlar',
        selectLanguage: 'Dil seçin',
        footerText: 'Sizin onlayn kitabxananız',
        aboutText: 'Scripta - kitabları onlayn oxumaq üçün müasir platforma',
        allRights: 'Bütün hüquqlar qorunur',
        home: 'Ana səhifə',
        filters: 'Filtrlər',
        genre: 'Janr',
        author: 'Müəllif',
        language: 'Dil',
        year: 'İl',
        all: 'Hamısı',
        authorName: 'Müəllifin adı',
        from: 'Dan',
        to: 'Dək',
        applyFilters: 'Tətbiq et',
        resetFilters: 'Sıfırla',
        found: 'Tapıldı',
        books: 'kitab',
        sortBy: 'Sıralama',
        popularity: 'Populyarlıq',
        date: 'Tarix',
        alphabet: 'Əlifba',
        rating: 'Reytinq',
        noResults: 'Kitab tapılmadı',
        description: 'Təsvir',
        formats: 'Formatlar',
        readOnline: 'Onlayn oxu',
        download: 'Yüklə',
        views: 'baxış',
        downloads: 'yükləmə',
        pages: 'Səhifələr'
    },
    ru: {
        catalog: 'Каталог',
        new: 'Новинки',
        favorites: 'Избранное',
        about: 'О нас',
        search: 'Поиск книг...',
        heroTitle: 'Твоя личная библиотека в кармане',
        heroSubtitle: 'Более 500 000 книг в одном сайте',
        startReading: 'Начать читать бесплатно',
        recommended: 'Рекомендуем',
        best: 'Лучшие',
        viewAll: 'Открыть все',
        genres: 'Жанры',
        selectLanguage: 'Выберите язык',
        footerText: 'Ваша онлайн библиотека',
        aboutText: 'Scripta - современная платформа для чтения книг онлайн',
        allRights: 'Все права защищены',
        home: 'Главная',
        filters: 'Фильтры',
        genre: 'Жанр',
        author: 'Автор',
        language: 'Язык',
        year: 'Год',
        all: 'Все',
        authorName: 'Имя автора',
        from: 'От',
        to: 'До',
        applyFilters: 'Применить',
        resetFilters: 'Сбросить',
        found: 'Найдено',
        books: 'книг',
        sortBy: 'Сортировка',
        popularity: 'Популярность',
        date: 'Дата добавления',
        alphabet: 'По алфавиту',
        rating: 'Рейтинг',
        noResults: 'Книги не найдены',
        description: 'Описание',
        formats: 'Форматы',
        readOnline: 'Читать онлайн',
        download: 'Скачать',
        views: 'просмотров',
        downloads: 'скачиваний',
        pages: 'Страниц'
    }
};

// Get current language from localStorage or default to 'ru'
let currentLang = localStorage.getItem('language') || 'ru';

// Function to update page language
function updateLanguage(lang) {
    currentLang = lang;
    localStorage.setItem('language', lang);
    document.documentElement.lang = lang;

    // Update all elements with data-key attribute
    document.querySelectorAll('[data-key]').forEach(element => {
        const key = element.getAttribute('data-key');
        if (translations[lang] && translations[lang][key]) {
            element.textContent = translations[lang][key];
        }
    });

    // Update all placeholders with data-key-placeholder attribute
    document.querySelectorAll('[data-key-placeholder]').forEach(element => {
        const key = element.getAttribute('data-key-placeholder');
        if (translations[lang] && translations[lang][key]) {
            element.placeholder = translations[lang][key];
        }
    });

    // Close modal if open
    const langModal = document.getElementById('langModal');
    if (langModal) {
        langModal.classList.remove('active');
    }
}

// Function to get translation
function t(key) {
    return translations[currentLang][key] || key;
}

// Initialize language on page load
document.addEventListener('DOMContentLoaded', () => {
    updateLanguage(currentLang);

    // Language button click handler
    const langBtn = document.getElementById('langBtn');
    const langModal = document.getElementById('langModal');
    
    if (langBtn && langModal) {
        langBtn.addEventListener('click', () => {
            langModal.classList.add('active');
        });

        langModal.addEventListener('click', (e) => {
            if (e.target === langModal) {
                langModal.classList.remove('active');
            }
        });

        // Language option click handlers
        document.querySelectorAll('.lang-option').forEach(option => {
            option.addEventListener('click', () => {
                const lang = option.getAttribute('data-lang');
                updateLanguage(lang);
            });
        });
    }
});
