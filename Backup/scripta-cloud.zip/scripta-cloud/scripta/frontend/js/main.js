// Main page functionality

// Catalog sidebar
const catalogBtn = document.getElementById('catalogBtn');
const catalogSidebar = document.getElementById('catalogSidebar');
const closeCatalog = document.getElementById('closeCatalog');
const ctaBtn = document.getElementById('ctaBtn');

if (catalogBtn) {
    catalogBtn.addEventListener('click', () => {
        catalogSidebar.classList.add('active');
    });
}

if (closeCatalog) {
    closeCatalog.addEventListener('click', () => {
        catalogSidebar.classList.remove('active');
    });
}

if (ctaBtn) {
    ctaBtn.addEventListener('click', () => {
        window.location.href = 'catalog.html';
    });
}

// Close sidebar on outside click
catalogSidebar?.addEventListener('click', (e) => {
    if (e.target === catalogSidebar) {
        catalogSidebar.classList.remove('active');
    }
});

// Load genres for sidebar
async function loadGenres() {
    try {
        const genres = await fetchAPI(API_ENDPOINTS.genres.getAll());
        const genresList = document.getElementById('genresList');
        
        if (genresList && genres) {
            genresList.innerHTML = genres.map(genre => `
                <li onclick="window.location.href='catalog.html?genre=${genre.id}'">${genre.name}</li>
            `).join('');
        }
    } catch (error) {
        console.error('Error loading genres:', error);
    }
}

// Create book card HTML
function createBookCard(book) {
    const badgeClass = book.badge === 'Новый' ? 'badge-new' : 
                       book.badge === 'Рекомендуем' ? 'badge-recommended' : 
                       'badge-best';
    
    const stars = Array(5).fill(0).map((_, i) => 
        `<span class="star ${i < Math.floor(book.rating) ? '' : 'empty'}">★</span>`
    ).join('');

    return `
        <a href="book.html?id=${book.id}" class="book-card">
            <div class="book-cover">
                ${book.coverUrl ? `<img src="${book.coverUrl}" alt="${book.title}">` : ''}
                ${book.badge ? `<div class="book-badge ${badgeClass}">${book.badge}</div>` : ''}
            </div>
            <div class="book-info">
                <h3 class="book-title">${book.title}</h3>
                <p class="book-author">${book.author}</p>
                <div class="book-rating">
                    <div class="stars">${stars}</div>
                    <span class="rating-value">${book.rating.toFixed(1)}</span>
                </div>
            </div>
        </a>
    `;
}

// Load books by category
async function loadBooksByCategory(category, containerId) {
    try {
        const books = await fetchAPI(API_ENDPOINTS.books.getByCategory(category));
        const container = document.getElementById(containerId);
        
        if (container && books) {
            // Show only first 6 books
            const displayBooks = books.slice(0, 6);
            container.innerHTML = displayBooks.map(book => createBookCard(book)).join('');
        }
    } catch (error) {
        console.error(`Error loading ${category} books:`, error);
    }
}

// Search functionality
const searchInput = document.getElementById('searchInput');
if (searchInput) {
    let searchTimeout;
    searchInput.addEventListener('input', (e) => {
        clearTimeout(searchTimeout);
        const query = e.target.value.trim();
        
        if (query.length >= 3) {
            searchTimeout = setTimeout(() => {
                window.location.href = `catalog.html?search=${encodeURIComponent(query)}`;
            }, 500);
        }
    });
}

// Initialize page
document.addEventListener('DOMContentLoaded', async () => {
    await loadGenres();
    await loadBooksByCategory('recommended', 'recommendedBooks');
    await loadBooksByCategory('new', 'newBooks');
    await loadBooksByCategory('best', 'bestBooks');
});
