// Book page functionality

let currentBook = null;

// Get book ID from URL
function getBookId() {
    const params = new URLSearchParams(window.location.search);
    return params.get('id');
}

// Display book details
function displayBook(book) {
    currentBook = book;

    // Cover
    const bookCover = document.getElementById('bookCover');
    if (bookCover) {
        bookCover.src = book.coverUrl || '';
        bookCover.alt = book.title;
    }

    // Badge
    const bookBadge = document.getElementById('bookBadge');
    if (bookBadge && book.badge) {
        const badgeClass = book.badge === 'Новый' ? 'badge-new' : 
                          book.badge === 'Рекомендуем' ? 'badge-recommended' : 
                          'badge-best';
        bookBadge.className = `book-badge ${badgeClass}`;
        bookBadge.textContent = book.badge;
    }

    // Title and author
    const bookTitle = document.getElementById('bookTitle');
    const bookAuthor = document.getElementById('bookAuthor');
    if (bookTitle) bookTitle.textContent = book.title;
    if (bookAuthor) bookAuthor.textContent = book.author;

    // Update page title
    document.title = `${book.title} - Scripta`;

    // Rating
    const bookStars = document.getElementById('bookStars');
    const ratingValue = document.getElementById('ratingValue');
    if (bookStars) {
        const stars = Array(5).fill(0).map((_, i) => 
            `<span class="star ${i < Math.floor(book.rating) ? '' : 'empty'}">★</span>`
        ).join('');
        bookStars.innerHTML = stars;
    }
    if (ratingValue) {
        ratingValue.textContent = book.rating.toFixed(1);
    }

    // Meta information
    const bookGenre = document.getElementById('bookGenre');
    const bookYear = document.getElementById('bookYear');
    const bookLanguage = document.getElementById('bookLanguage');
    const bookPages = document.getElementById('bookPages');

    if (bookGenre) bookGenre.textContent = book.genre;
    if (bookYear) bookYear.textContent = book.year;
    if (bookLanguage) {
        const langNames = { az: 'Azərbaycan', ru: 'Русский', en: 'English' };
        bookLanguage.textContent = langNames[book.language] || book.language;
    }
    if (bookPages) bookPages.textContent = book.pages || 'N/A';

    // Description
    const bookDescription = document.getElementById('bookDescription');
    if (bookDescription) {
        bookDescription.textContent = book.description;
    }

    // Formats
    const formatBadges = document.getElementById('formatBadges');
    if (formatBadges && book.formats) {
        formatBadges.innerHTML = book.formats.map(format => 
            `<span class="format-badge">${format.toUpperCase()}</span>`
        ).join('');
    }

    // Stats
    const viewCount = document.getElementById('viewCount');
    const downloadCount = document.getElementById('downloadCount');
    if (viewCount) viewCount.textContent = book.viewCount || 0;
    if (downloadCount) downloadCount.textContent = book.downloadCount || 0;
}

// Load book data
async function loadBook() {
    const bookId = getBookId();
    if (!bookId) {
        window.location.href = 'catalog.html';
        return;
    }

    try {
        const book = await fetchAPI(API_ENDPOINTS.books.getById(bookId));
        if (book) {
            displayBook(book);
            
            // Increment view count
            await fetchAPI(API_ENDPOINTS.books.incrementView(bookId), { method: 'POST' });
        }
    } catch (error) {
        console.error('Error loading book:', error);
        alert('Ошибка загрузки книги');
    }
}

// Read online functionality
const readOnlineBtn = document.getElementById('readOnlineBtn');
const readerModal = document.getElementById('readerModal');
const closeReader = document.getElementById('closeReader');
const pdfViewer = document.getElementById('pdfViewer');
const readerTitle = document.getElementById('readerTitle');

if (readOnlineBtn) {
    readOnlineBtn.addEventListener('click', () => {
        if (currentBook && currentBook.fileUrl) {
            readerModal.classList.add('active');
            if (readerTitle) readerTitle.textContent = currentBook.title;
            
            // For PDF viewing, we use browser's built-in PDF viewer
            pdfViewer.src = currentBook.fileUrl;
        } else {
            alert('Файл книги недоступен');
        }
    });
}

if (closeReader) {
    closeReader.addEventListener('click', () => {
        readerModal.classList.remove('active');
        pdfViewer.src = '';
    });
}

// Download functionality
const downloadBtn = document.getElementById('downloadBtn');
if (downloadBtn) {
    downloadBtn.addEventListener('click', async () => {
        if (currentBook && currentBook.fileUrl) {
            // Increment download count
            try {
                await fetchAPI(API_ENDPOINTS.books.incrementDownload(currentBook.id), { method: 'POST' });
                
                // Update display
                const downloadCount = document.getElementById('downloadCount');
                if (downloadCount) {
                    downloadCount.textContent = parseInt(downloadCount.textContent) + 1;
                }
            } catch (error) {
                console.error('Error incrementing download count:', error);
            }

            // Trigger download
            const link = document.createElement('a');
            link.href = currentBook.fileUrl;
            link.download = `${currentBook.title}.pdf`;
            link.click();
        } else {
            alert('Файл книги недоступен');
        }
    });
}

// Close reader on Escape key
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && readerModal.classList.contains('active')) {
        readerModal.classList.remove('active');
        pdfViewer.src = '';
    }
});

// Initialize page
document.addEventListener('DOMContentLoaded', () => {
    loadBook();
});
