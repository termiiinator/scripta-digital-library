// Theme management
let currentTheme = localStorage.getItem('theme') || 'light';

function setTheme(theme) {
    currentTheme = theme;
    localStorage.setItem('theme', theme);
    document.documentElement.setAttribute('data-theme', theme);
    
    // Update theme icon
    const themeIcon = document.querySelector('.theme-icon');
    if (themeIcon) {
        if (theme === 'dark') {
            themeIcon.innerHTML = `
                <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" fill="currentColor"/>
            `;
        } else {
            themeIcon.innerHTML = `
                <circle cx="10" cy="10" r="5" fill="currentColor"/>
                <g class="rays">
                    <line x1="10" y1="1" x2="10" y2="3" stroke="currentColor" stroke-width="2"/>
                    <line x1="10" y1="17" x2="10" y2="19" stroke="currentColor" stroke-width="2"/>
                    <line x1="3.22" y1="3.22" x2="4.64" y2="4.64" stroke="currentColor" stroke-width="2"/>
                    <line x1="15.36" y1="15.36" x2="16.78" y2="16.78" stroke="currentColor" stroke-width="2"/>
                    <line x1="1" y1="10" x2="3" y2="10" stroke="currentColor" stroke-width="2"/>
                    <line x1="17" y1="10" x2="19" y2="10" stroke="currentColor" stroke-width="2"/>
                    <line x1="3.22" y1="16.78" x2="4.64" y2="15.36" stroke="currentColor" stroke-width="2"/>
                    <line x1="15.36" y1="4.64" x2="16.78" y2="3.22" stroke="currentColor" stroke-width="2"/>
                </g>
            `;
        }
    }
}

function toggleTheme() {
    const newTheme = currentTheme === 'light' ? 'dark' : 'light';
    setTheme(newTheme);
}

// Initialize theme on page load
document.addEventListener('DOMContentLoaded', () => {
    setTheme(currentTheme);
    
    const themeBtn = document.getElementById('themeBtn');
    if (themeBtn) {
        themeBtn.addEventListener('click', toggleTheme);
    }
});
