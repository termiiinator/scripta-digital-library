# Scripta - Онлайн Библиотека

Полнофункциональная веб-платформа для онлайн-чтения и управления электронной библиотекой.

## 📋 Описание

Scripta - современная онлайн-библиотека с удобным интерфейсом, поддержкой мультиязычности (Азербайджанский/Русский), светлой и тёмной темой, системой фильтрации и поиска книг.

## 🏗️ Архитектура проекта

```
scripta/
├── frontend/           # Frontend приложение
│   ├── css/           # Стили
│   ├── js/            # JavaScript файлы
│   ├── index.html     # Главная страница
│   ├── catalog.html   # Страница каталога
│   └── book.html      # Страница книги
├── backend/           # ASP.NET Core Web API
│   ├── Controllers/   # API контроллеры
│   ├── Models/        # Модели данных
│   ├── Services/      # Бизнес-логика
│   ├── Data/          # Database context
│   └── Program.cs     # Точка входа
├── database/          # SQL скрипты
│   └── init.sql       # Инициализация БД
└── README.md
```

## 🛠️ Технологический стек

### Frontend
- **HTML5** - разметка
- **CSS3** - стилизация (Flexbox, Grid, CSS Variables)
- **JavaScript** (Vanilla) - логика без фреймворков
- **Fetch API** - взаимодействие с backend

### Backend
- **C#** (.NET 8.0)
- **ASP.NET Core Web API** - REST API
- **Entity Framework Core** - ORM
- **PostgreSQL** - база данных

### Архитектура Backend
- **Controllers** - обработка HTTP запросов
- **Services** - бизнес-логика
- **Models** - модели данных
- **Data** - контекст базы данных и seed

## ✨ Основные функции

### Frontend
- ✅ Адаптивный дизайн (desktop + mobile)
- ✅ Светлая и тёмная тема
- ✅ Мультиязычность (Азербайджанский/Русский)
- ✅ 3D анимации книг
- ✅ Каталог с фильтрацией
- ✅ Поиск книг
- ✅ Онлайн чтение (PDF viewer)
- ✅ Скачивание книг
- ✅ Статистика просмотров/скачиваний

### Backend
- ✅ REST API эндпоинты
- ✅ CRUD операции
- ✅ Фильтрация и сортировка
- ✅ Поиск
- ✅ Статистика
- ✅ Seed данных (15 книг)

## 🚀 Установка и запуск

### Требования
- .NET 8.0 SDK
- PostgreSQL 14+
- Любой веб-браузер

### 1. Установка PostgreSQL

**Windows:**
```bash
# Скачать с официального сайта: https://www.postgresql.org/download/windows/
# Установить с настройками по умолчанию
# Запомнить пароль для пользователя postgres
```

**macOS:**
```bash
brew install postgresql@14
brew services start postgresql@14
```

**Linux (Ubuntu/Debian):**
```bash
sudo apt update
sudo apt install postgresql postgresql-contrib
sudo systemctl start postgresql
```

### 2. Создание базы данных

```bash
# Подключиться к PostgreSQL
psql -U postgres

# Создать базу данных (в psql консоли)
CREATE DATABASE scripta;

# Выйти
\q

# Или использовать готовый SQL скрипт
psql -U postgres -f database/init.sql
```

### 3. Настройка Backend

```bash
# Перейти в папку backend
cd backend

# Восстановить зависимости
dotnet restore

# Применить миграции (если используются)
dotnet ef database update

# Запустить сервер
dotnet run
```

Backend будет доступен по адресу: **http://localhost:5000**

Swagger UI: **http://localhost:5000/swagger**

### 4. Настройка Frontend

```bash
# Перейти в папку frontend
cd frontend

# Запустить локальный веб-сервер
# Вариант 1: Python
python -m http.server 8080

# Вариант 2: Node.js (npx)
npx http-server -p 8080

# Вариант 3: PHP
php -S localhost:8080
```

Frontend будет доступен по адресу: **http://localhost:8080**

### 5. Настройка подключения

Убедитесь, что в файле `backend/appsettings.json` указаны правильные данные подключения:

```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Host=localhost;Port=5432;Database=scripta;Username=postgres;Password=ВАШ_ПАРОЛЬ"
  }
}
```

И в файле `frontend/js/config.js`:

```javascript
const API_BASE_URL = 'http://localhost:5000/api';
```

## 📡 API Эндпоинты

### Books
- `GET /api/books` - получить все книги
- `GET /api/books/{id}` - получить книгу по ID
- `GET /api/books/category/{category}` - книги по категории (recommended/new/best)
- `GET /api/books/search?q={query}` - поиск книг
- `POST /api/books/{id}/view` - увеличить счётчик просмотров
- `POST /api/books/{id}/download` - увеличить счётчик скачиваний

### Genres
- `GET /api/genres` - получить все жанры

### Authors
- `GET /api/authors` - получить всех авторов

## 🎨 Особенности дизайна

- **Современный минимализм** - чистый интерфейс без лишних элементов
- **CSS переменные** - легкое переключение тем
- **Плавные анимации** - transitions и transforms
- **Адаптивная сетка** - CSS Grid и Flexbox
- **3D эффекты** - для обложек книг
- **Градиенты** - современные цветовые схемы

## 🌍 Мультиязычность

Поддерживаемые языки:
- **Азербайджанский** (az)
- **Русский** (ru)

Переключение языка через кнопку в header. Выбранный язык сохраняется в localStorage.

## 🎯 Структура базы данных

### Таблицы

**Authors** - авторы
- Id (PK)
- Name
- Biography

**Genres** - жанры
- Id (PK)
- Name
- Description

**Books** - книги
- Id (PK)
- Title
- Description
- AuthorId (FK)
- GenreId (FK)
- Language
- Year
- Pages
- Rating
- CoverUrl
- FileUrl
- Formats
- Badge
- ViewCount
- DownloadCount
- CreatedAt

## 🔧 Разработка

### Добавление новых книг

Через Seed в `Data/ApplicationDbContext.cs`:

```csharp
new Book
{
    Title = "Название",
    Description = "Описание",
    AuthorId = 1,
    GenreId = 1,
    Language = "ru",
    Year = 2024,
    Pages = 300,
    Rating = 4.5m,
    CoverUrl = "https://...",
    FileUrl = "/files/...",
    Formats = "PDF,EPUB",
    Badge = "Новый"
}
```

### Кастомизация стилей

Изменить CSS переменные в `frontend/css/styles.css`:

```css
:root {
    --primary-color: #6366f1;
    --secondary-color: #8b5cf6;
    /* ... */
}
```

## 📝 Лицензия

MIT License

## 👨‍💻 Автор

Scripta Library System

---

## ⚠️ Важные примечания

1. **Файлы книг**: В текущей версии используются placeholder URL. Для реальных файлов создайте папку `backend/wwwroot/files/` и разместите там PDF файлы.

2. **Изображения**: Используются URL из Unsplash. Для production лучше загрузить локально.

3. **CORS**: Настроен для разработки (`AllowAll`). Для production ограничьте origins.

4. **Безопасность**: Добавьте аутентификацию для административной панели.

## 🐛 Troubleshooting

**Проблема**: Backend не запускается
- Проверьте установку .NET 8.0 SDK
- Проверьте подключение к PostgreSQL
- Проверьте строку подключения в appsettings.json

**Проблема**: Frontend не видит API
- Проверьте CORS настройки
- Убедитесь что backend запущен на порту 5000
- Проверьте консоль браузера на ошибки

**Проблема**: База данных пустая
- Удалите и пересоздайте БД
- Запустите backend - seed выполнится автоматически
- Или выполните init.sql вручную

## 📞 Поддержка

Если возникли проблемы:
1. Проверьте все requirements
2. Убедитесь что все сервисы запущены
3. Проверьте логи backend
4. Проверьте console в браузере
