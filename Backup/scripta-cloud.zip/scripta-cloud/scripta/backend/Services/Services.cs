using Microsoft.EntityFrameworkCore;
using ScriptaAPI.Data;
using ScriptaAPI.Models;

namespace ScriptaAPI.Services
{
    public interface IBookService
    {
        Task<IEnumerable<object>> GetAllBooksAsync();
        Task<object?> GetBookByIdAsync(int id);
        Task<IEnumerable<object>> GetBooksByCategoryAsync(string category);
        Task<IEnumerable<object>> SearchBooksAsync(string query);
        Task IncrementViewCountAsync(int id);
        Task IncrementDownloadCountAsync(int id);
    }

    public class BookService : IBookService
    {
        private readonly ApplicationDbContext _context;

        public BookService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<object>> GetAllBooksAsync()
        {
            return await _context.Books
                .Include(b => b.Author)
                .Include(b => b.Genre)
                .Select(b => new
                {
                    b.Id,
                    b.Title,
                    b.Description,
                    Author = b.Author.Name,
                    Genre = b.Genre.Name,
                    b.GenreId,
                    b.Language,
                    b.Year,
                    b.Pages,
                    b.Rating,
                    b.CoverUrl,
                    b.FileUrl,
                    Formats = b.Formats.Split(',').ToList(),
                    b.Badge,
                    b.ViewCount,
                    b.DownloadCount,
                    b.CreatedAt
                })
                .ToListAsync();
        }

        public async Task<object?> GetBookByIdAsync(int id)
        {
            var book = await _context.Books
                .Include(b => b.Author)
                .Include(b => b.Genre)
                .Where(b => b.Id == id)
                .Select(b => new
                {
                    b.Id,
                    b.Title,
                    b.Description,
                    Author = b.Author.Name,
                    Genre = b.Genre.Name,
                    b.GenreId,
                    b.Language,
                    b.Year,
                    b.Pages,
                    b.Rating,
                    b.CoverUrl,
                    b.FileUrl,
                    Formats = b.Formats.Split(',').ToList(),
                    b.Badge,
                    b.ViewCount,
                    b.DownloadCount,
                    b.CreatedAt
                })
                .FirstOrDefaultAsync();

            return book;
        }

        public async Task<IEnumerable<object>> GetBooksByCategoryAsync(string category)
        {
            var query = _context.Books
                .Include(b => b.Author)
                .Include(b => b.Genre)
                .AsQueryable();

            query = category.ToLower() switch
            {
                "recommended" => query.Where(b => b.Badge == "Рекомендуем"),
                "new" => query.Where(b => b.Badge == "Новый"),
                "best" => query.Where(b => b.Badge == "Лучший"),
                _ => query
            };

            return await query
                .Select(b => new
                {
                    b.Id,
                    b.Title,
                    b.Description,
                    Author = b.Author.Name,
                    Genre = b.Genre.Name,
                    b.GenreId,
                    b.Language,
                    b.Year,
                    b.Pages,
                    b.Rating,
                    b.CoverUrl,
                    b.FileUrl,
                    Formats = b.Formats.Split(',').ToList(),
                    b.Badge,
                    b.ViewCount,
                    b.DownloadCount,
                    b.CreatedAt
                })
                .ToListAsync();
        }

        public async Task<IEnumerable<object>> SearchBooksAsync(string query)
        {
            var searchTerm = query.ToLower();

            return await _context.Books
                .Include(b => b.Author)
                .Include(b => b.Genre)
                .Where(b => b.Title.ToLower().Contains(searchTerm) ||
                           b.Description.ToLower().Contains(searchTerm) ||
                           b.Author.Name.ToLower().Contains(searchTerm))
                .Select(b => new
                {
                    b.Id,
                    b.Title,
                    b.Description,
                    Author = b.Author.Name,
                    Genre = b.Genre.Name,
                    b.GenreId,
                    b.Language,
                    b.Year,
                    b.Pages,
                    b.Rating,
                    b.CoverUrl,
                    b.FileUrl,
                    Formats = b.Formats.Split(',').ToList(),
                    b.Badge,
                    b.ViewCount,
                    b.DownloadCount,
                    b.CreatedAt
                })
                .ToListAsync();
        }

        public async Task IncrementViewCountAsync(int id)
        {
            var book = await _context.Books.FindAsync(id);
            if (book != null)
            {
                book.ViewCount++;
                await _context.SaveChangesAsync();
            }
        }

        public async Task IncrementDownloadCountAsync(int id)
        {
            var book = await _context.Books.FindAsync(id);
            if (book != null)
            {
                book.DownloadCount++;
                await _context.SaveChangesAsync();
            }
        }
    }

    public interface IGenreService
    {
        Task<IEnumerable<Genre>> GetAllGenresAsync();
    }

    public class GenreService : IGenreService
    {
        private readonly ApplicationDbContext _context;

        public GenreService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Genre>> GetAllGenresAsync()
        {
            return await _context.Genres.ToListAsync();
        }
    }

    public interface IAuthorService
    {
        Task<IEnumerable<Author>> GetAllAuthorsAsync();
    }

    public class AuthorService : IAuthorService
    {
        private readonly ApplicationDbContext _context;

        public AuthorService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Author>> GetAllAuthorsAsync()
        {
            return await _context.Authors.ToListAsync();
        }
    }
}
