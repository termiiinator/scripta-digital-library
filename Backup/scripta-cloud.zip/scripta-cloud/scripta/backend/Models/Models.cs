using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ScriptaAPI.Models
{
    public class Book
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [MaxLength(500)]
        public string Title { get; set; } = string.Empty;

        [MaxLength(2000)]
        public string Description { get; set; } = string.Empty;

        public int AuthorId { get; set; }
        
        [ForeignKey("AuthorId")]
        public Author Author { get; set; } = null!;

        public int GenreId { get; set; }
        
        [ForeignKey("GenreId")]
        public Genre Genre { get; set; } = null!;

        [MaxLength(10)]
        public string Language { get; set; } = "ru";

        public int Year { get; set; }

        public int Pages { get; set; }

        [Column(TypeName = "decimal(3,2)")]
        public decimal Rating { get; set; }

        [MaxLength(500)]
        public string? CoverUrl { get; set; }

        [MaxLength(500)]
        public string? FileUrl { get; set; }

        [MaxLength(100)]
        public string Formats { get; set; } = "PDF";

        [MaxLength(50)]
        public string? Badge { get; set; }

        public int ViewCount { get; set; }

        public int DownloadCount { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }

    public class Author
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [MaxLength(200)]
        public string Name { get; set; } = string.Empty;

        [MaxLength(1000)]
        public string? Biography { get; set; }

        public ICollection<Book> Books { get; set; } = new List<Book>();
    }

    public class Genre
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [MaxLength(100)]
        public string Name { get; set; } = string.Empty;

        [MaxLength(500)]
        public string? Description { get; set; }

        public ICollection<Book> Books { get; set; } = new List<Book>();
    }
}
