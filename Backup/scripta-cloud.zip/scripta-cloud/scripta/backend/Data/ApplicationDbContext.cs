using Microsoft.EntityFrameworkCore;
using ScriptaAPI.Models;

namespace ScriptaAPI.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Book> Books { get; set; }
        public DbSet<Author> Authors { get; set; }
        public DbSet<Genre> Genres { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Configure relationships
            modelBuilder.Entity<Book>()
                .HasOne(b => b.Author)
                .WithMany(a => a.Books)
                .HasForeignKey(b => b.AuthorId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Book>()
                .HasOne(b => b.Genre)
                .WithMany(g => g.Books)
                .HasForeignKey(b => b.GenreId)
                .OnDelete(DeleteBehavior.Restrict);

            // Indexes
            modelBuilder.Entity<Book>()
                .HasIndex(b => b.Title);

            modelBuilder.Entity<Book>()
                .HasIndex(b => b.Rating);

            modelBuilder.Entity<Book>()
                .HasIndex(b => b.CreatedAt);
        }
    }

    public static class DbInitializer
    {
        public static void Initialize(ApplicationDbContext context)
        {
            // Check if database is already seeded
            if (context.Books.Any())
            {
                return;
            }

            // Seed Genres
            var genres = new Genre[]
            {
                new Genre { Name = "Роман", Description = "Художественная проза" },
                new Genre { Name = "Детектив", Description = "Детективные истории" },
                new Genre { Name = "Фантастика", Description = "Научная фантастика" },
                new Genre { Name = "Фэнтези", Description = "Фэнтези произведения" },
                new Genre { Name = "Классика", Description = "Классическая литература" },
                new Genre { Name = "Поэзия", Description = "Стихи и поэмы" },
                new Genre { Name = "Бизнес", Description = "Деловая литература" },
                new Genre { Name = "Психология", Description = "Психологические книги" },
                new Genre { Name = "История", Description = "Исторические произведения" },
                new Genre { Name = "Биография", Description = "Биографии известных людей" }
            };
            context.Genres.AddRange(genres);
            context.SaveChanges();

            // Seed Authors
            var authors = new Author[]
            {
                new Author { Name = "Федор Достоевский", Biography = "Русский писатель, мыслитель" },
                new Author { Name = "Лев Толстой", Biography = "Русский писатель и мыслитель" },
                new Author { Name = "Антон Чехов", Biography = "Русский писатель и драматург" },
                new Author { Name = "Александр Пушкин", Biography = "Русский поэт и писатель" },
                new Author { Name = "Михаил Булгаков", Biography = "Русский писатель и драматург" },
                new Author { Name = "Айн Рэнд", Biography = "Американская писательница" },
                new Author { Name = "Джордж Оруэлл", Biography = "Английский писатель и публицист" },
                new Author { Name = "Рэй Брэдбери", Biography = "Американский писатель-фантаст" },
                new Author { Name = "Артур Конан Дойл", Biography = "Британский писатель" },
                new Author { Name = "Агата Кристи", Biography = "Английская писательница" },
                new Author { Name = "Дж.Р.Р. Толкин", Biography = "Английский писатель и филолог" },
                new Author { Name = "Джоан Роулинг", Biography = "Британская писательница" },
                new Author { Name = "Стивен Кинг", Biography = "Американский писатель" },
                new Author { Name = "Харуки Мураками", Biography = "Японский писатель" },
                new Author { Name = "Габриэль Гарсиа Маркес", Biography = "Колумбийский писатель" }
            };
            context.Authors.AddRange(authors);
            context.SaveChanges();

            // Seed Books
            var books = new Book[]
            {
                new Book
                {
                    Title = "Преступление и наказание",
                    Description = "Психологический и философский роман о студенте Раскольникове",
                    AuthorId = 1,
                    GenreId = 5,
                    Language = "ru",
                    Year = 1866,
                    Pages = 671,
                    Rating = 4.8m,
                    CoverUrl = "https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=400",
                    FileUrl = "/files/crime-and-punishment.pdf",
                    Formats = "PDF,EPUB,FB2",
                    Badge = "Лучший",
                    ViewCount = 15420,
                    DownloadCount = 8234
                },
                new Book
                {
                    Title = "Война и мир",
                    Description = "Роман-эпопея о жизни русского общества в эпоху войн против Наполеона",
                    AuthorId = 2,
                    GenreId = 5,
                    Language = "ru",
                    Year = 1869,
                    Pages = 1225,
                    Rating = 4.9m,
                    CoverUrl = "https://images.unsplash.com/photo-1512820790803-83ca734da794?w=400",
                    FileUrl = "/files/war-and-peace.pdf",
                    Formats = "PDF,EPUB",
                    Badge = "Лучший",
                    ViewCount = 18935,
                    DownloadCount = 9821
                },
                new Book
                {
                    Title = "Мастер и Маргарита",
                    Description = "Мистический роман о дьяволе, посетившем Москву 1930-х годов",
                    AuthorId = 5,
                    GenreId = 1,
                    Language = "ru",
                    Year = 1967,
                    Pages = 480,
                    Rating = 4.7m,
                    CoverUrl = "https://images.unsplash.com/photo-1509021436665-8f07dbf5bf1d?w=400",
                    FileUrl = "/files/master-and-margarita.pdf",
                    Formats = "PDF,EPUB,FB2",
                    Badge = "Рекомендуем",
                    ViewCount = 12563,
                    DownloadCount = 7124
                },
                new Book
                {
                    Title = "1984",
                    Description = "Антиутопия о тоталитарном обществе будущего",
                    AuthorId = 7,
                    GenreId = 3,
                    Language = "ru",
                    Year = 1949,
                    Pages = 328,
                    Rating = 4.6m,
                    CoverUrl = "https://images.unsplash.com/photo-1495446815901-a7297e633e8d?w=400",
                    FileUrl = "/files/1984.pdf",
                    Formats = "PDF,EPUB",
                    Badge = "Рекомендуем",
                    ViewCount = 14782,
                    DownloadCount = 8956
                },
                new Book
                {
                    Title = "Шерлок Холмс. Полное собрание",
                    Description = "Все рассказы и повести о знаменитом детективе",
                    AuthorId = 9,
                    GenreId = 2,
                    Language = "ru",
                    Year = 1927,
                    Pages = 1056,
                    Rating = 4.8m,
                    CoverUrl = "https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=400",
                    FileUrl = "/files/sherlock-holmes.pdf",
                    Formats = "PDF,EPUB,FB2",
                    Badge = "Лучший",
                    ViewCount = 16234,
                    DownloadCount = 9432
                },
                new Book
                {
                    Title = "Убийство в Восточном экспрессе",
                    Description = "Классический детектив Агаты Кристи",
                    AuthorId = 10,
                    GenreId = 2,
                    Language = "ru",
                    Year = 1934,
                    Pages = 256,
                    Rating = 4.5m,
                    CoverUrl = "https://images.unsplash.com/photo-1543002588-bfa74002ed7e?w=400",
                    FileUrl = "/files/murder-orient-express.pdf",
                    Formats = "PDF,EPUB",
                    Badge = "Новый",
                    ViewCount = 8945,
                    DownloadCount = 5234
                },
                new Book
                {
                    Title = "Властелин колец",
                    Description = "Эпическая трилогия о Средиземье",
                    AuthorId = 11,
                    GenreId = 4,
                    Language = "ru",
                    Year = 1954,
                    Pages = 1178,
                    Rating = 4.9m,
                    CoverUrl = "https://images.unsplash.com/photo-1589998059171-988d887df646?w=400",
                    FileUrl = "/files/lotr.pdf",
                    Formats = "PDF,EPUB,FB2",
                    Badge = "Лучший",
                    ViewCount = 22456,
                    DownloadCount = 13245
                },
                new Book
                {
                    Title = "Гарри Поттер и философский камень",
                    Description = "Первая книга о юном волшебнике",
                    AuthorId = 12,
                    GenreId = 4,
                    Language = "ru",
                    Year = 1997,
                    Pages = 332,
                    Rating = 4.7m,
                    CoverUrl = "https://images.unsplash.com/photo-1621351183012-e2f9972dd9bf?w=400",
                    FileUrl = "/files/harry-potter-1.pdf",
                    Formats = "PDF,EPUB",
                    Badge = "Рекомендуем",
                    ViewCount = 19234,
                    DownloadCount = 11567
                },
                new Book
                {
                    Title = "451 градус по Фаренгейту",
                    Description = "Антиутопия о будущем, где книги запрещены",
                    AuthorId = 8,
                    GenreId = 3,
                    Language = "ru",
                    Year = 1953,
                    Pages = 256,
                    Rating = 4.6m,
                    CoverUrl = "https://images.unsplash.com/photo-1524995997946-a1c2e315a42f?w=400",
                    FileUrl = "/files/fahrenheit-451.pdf",
                    Formats = "PDF,EPUB,FB2",
                    Badge = "Рекомендуем",
                    ViewCount = 10456,
                    DownloadCount = 6789
                },
                new Book
                {
                    Title = "Анна Каренина",
                    Description = "Роман о трагической любви",
                    AuthorId = 2,
                    GenreId = 5,
                    Language = "ru",
                    Year = 1877,
                    Pages = 864,
                    Rating = 4.7m,
                    CoverUrl = "https://images.unsplash.com/photo-1553729459-efe14ef6055d?w=400",
                    FileUrl = "/files/anna-karenina.pdf",
                    Formats = "PDF,EPUB",
                    Badge = "Лучший",
                    ViewCount = 13567,
                    DownloadCount = 7890
                },
                new Book
                {
                    Title = "Евгений Онегин",
                    Description = "Роман в стихах Александра Пушкина",
                    AuthorId = 4,
                    GenreId = 6,
                    Language = "ru",
                    Year = 1833,
                    Pages = 224,
                    Rating = 4.5m,
                    CoverUrl = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400",
                    FileUrl = "/files/eugene-onegin.pdf",
                    Formats = "PDF,EPUB,FB2",
                    Badge = "Новый",
                    ViewCount = 9234,
                    DownloadCount = 5678
                },
                new Book
                {
                    Title = "Вишневый сад",
                    Description = "Пьеса Антона Чехова",
                    AuthorId = 3,
                    GenreId = 5,
                    Language = "ru",
                    Year = 1904,
                    Pages = 96,
                    Rating = 4.4m,
                    CoverUrl = "https://images.unsplash.com/photo-1516979187457-637abb4f9353?w=400",
                    FileUrl = "/files/cherry-orchard.pdf",
                    Formats = "PDF,EPUB",
                    Badge = "Новый",
                    ViewCount = 7456,
                    DownloadCount = 4123
                },
                new Book
                {
                    Title = "Норвежский лес",
                    Description = "Роман о любви и взрослении",
                    AuthorId = 14,
                    GenreId = 1,
                    Language = "ru",
                    Year = 1987,
                    Pages = 296,
                    Rating = 4.3m,
                    CoverUrl = "https://images.unsplash.com/photo-1497633762265-9d179a990aa6?w=400",
                    FileUrl = "/files/norwegian-wood.pdf",
                    Formats = "PDF,EPUB",
                    Badge = "Новый",
                    ViewCount = 8123,
                    DownloadCount = 4567
                },
                new Book
                {
                    Title = "Сто лет одиночества",
                    Description = "Магический реализм от Маркеса",
                    AuthorId = 15,
                    GenreId = 1,
                    Language = "ru",
                    Year = 1967,
                    Pages = 448,
                    Rating = 4.6m,
                    CoverUrl = "https://images.unsplash.com/photo-1519682337058-a94d519337bc?w=400",
                    FileUrl = "/files/one-hundred-years.pdf",
                    Formats = "PDF,EPUB,FB2",
                    Badge = "Рекомендуем",
                    ViewCount = 11234,
                    DownloadCount = 6789
                },
                new Book
                {
                    Title = "Атлант расправил плечи",
                    Description = "Философский роман о капитализме",
                    AuthorId = 6,
                    GenreId = 1,
                    Language = "ru",
                    Year = 1957,
                    Pages = 1168,
                    Rating = 4.5m,
                    CoverUrl = "https://images.unsplash.com/photo-1476275466078-4007374efbbe?w=400",
                    FileUrl = "/files/atlas-shrugged.pdf",
                    Formats = "PDF,EPUB",
                    Badge = "Рекомендуем",
                    ViewCount = 9876,
                    DownloadCount = 5432
                }
            };

            context.Books.AddRange(books);
            context.SaveChanges();
        }
    }
}
